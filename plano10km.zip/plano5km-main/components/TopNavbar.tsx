import React, { useState } from 'react';
import type { ProgramSection, WorkoutLog } from '../types';
import { FlagIcon, HistoryIcon, ArrowTrendingUpIcon, InfoIcon, TargetIcon, MenuIcon } from './icons';

type View = 'plan' | 'history' | 'goals' | 'progress';

interface TopNavbarProps {
  programContent: ProgramSection[];
  activeSectionId: string;
  onSelectSection: (id: string) => void;
  workoutLogs: Record<string, WorkoutLog[]>;
  currentView: View;
  setCurrentView: (view: View) => void;
}

const TopNavbar: React.FC<TopNavbarProps> = ({
  programContent,
  activeSectionId,
  onSelectSection,
  workoutLogs,
  currentView,
  setCurrentView,
}) => {
  const [isPlanDropdownOpen, setPlanDropdownOpen] = useState(false);
  const [isMoreDropdownOpen, setMoreDropdownOpen] = useState(false);

  const handleMainViewClick = (view: View) => {
    setCurrentView(view);
    setPlanDropdownOpen(view === 'plan');
    setMoreDropdownOpen(['history', 'goals', 'progress'].includes(view));
  };

  const handleSectionSelect = (id: string) => {
    onSelectSection(id);
    setPlanDropdownOpen(false);
  };
  
  const sectionIsLoggable = (id: string): boolean => {
    const section = programContent.find(s => s.id === id);
    return section?.isLoggable ?? false;
  };

  return (
    <nav className="bg-white shadow-md p-4 flex flex-col md:flex-row md:items-center sticky top-0 z-10">
      {/* Espaço vazio para balancear o título centralizado em telas maiores */}
      <div className="hidden md:flex-1 md:block"></div> 

      {/* Título centralizado */}
      <div className="flex-1 text-center mb-4 md:mb-0">
        <h1 className="text-2xl font-bold text-brand-blue">Plano 5km</h1>
      </div>

      {/* Navegação principal à direita */}
      <div className="flex-1 flex flex-wrap gap-2 md:gap-4 items-center justify-center md:justify-end">
        {/* Main View Navigation - Plano */}
        <div className="relative">
          <button
            onClick={() => handleMainViewClick('plan')}
            className={`px-3 py-2 flex items-center gap-2 rounded-md transition-colors text-sm ${
              currentView === 'plan'
                ? 'bg-brand-blue text-white shadow-sm'
                : 'text-gray-700 hover:bg-gray-200 hover:text-gray-900'
            }`}
          >
            <FlagIcon className="w-4 h-4" />
            <span>Plano</span>
            <svg className={`ml-2 h-4 w-4 transition-transform ${isPlanDropdownOpen && currentView === 'plan' ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          {isPlanDropdownOpen && currentView === 'plan' && (
            <div className="absolute left-0 mt-2 w-full md:w-60 bg-white border border-gray-200 rounded-md shadow-lg z-20 max-h-60 overflow-y-auto">
              {programContent.map(section => (
                <button
                  key={section.id}
                  onClick={() => handleSectionSelect(section.id)}
                  className={`block w-full text-left px-4 py-2 text-sm ${
                    activeSectionId === section.id ? 'bg-brand-blue text-white' : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  {section.title}
                  {sectionIsLoggable(section.id) && workoutLogs[section.id] && workoutLogs[section.id].length > 0 && <span className="w-2 h-2 rounded-full bg-blue-500 ml-2 inline-block" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* New 'Mais' (More) Dropdown */}
        <div className="relative">
          <button
            onClick={() => setMoreDropdownOpen(!isMoreDropdownOpen)}
            className={`px-3 py-2 flex items-center gap-2 rounded-md transition-colors text-sm ${
              ['history', 'goals', 'progress'].includes(currentView)
                ? 'bg-brand-blue text-white shadow-sm'
                : 'text-gray-700 hover:bg-gray-200 hover:text-gray-900'
            }`}
          >
            <MenuIcon className="w-4 h-4" />
            <span>Mais</span>
            <svg className={`ml-2 h-4 w-4 transition-transform ${isMoreDropdownOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          {isMoreDropdownOpen && (
            <div className="absolute left-0 mt-2 w-full md:w-40 bg-white border border-gray-200 rounded-md shadow-lg z-20">
              <button
                onClick={() => handleMainViewClick('history')}
                className={`block w-full text-left px-4 py-2 text-sm ${
                  currentView === 'history' ? 'bg-brand-blue text-white' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <HistoryIcon className="inline-block mr-2 w-4 h-4"/>
                Histórico
              </button>
              <button
                onClick={() => handleMainViewClick('goals')}
                className={`block w-full text-left px-4 py-2 text-sm ${
                  currentView === 'goals' ? 'bg-brand-blue text-white' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <TargetIcon className="inline-block mr-2 w-4 h-4"/>
                Metas
              </button>
              <button
                onClick={() => handleMainViewClick('progress')}
                className={`block w-full text-left px-4 py-2 text-sm ${
                  currentView === 'progress' ? 'bg-brand-blue text-white' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <ArrowTrendingUpIcon className="inline-block mr-2 w-4 h-4"/>
                Progresso
              </button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default TopNavbar;