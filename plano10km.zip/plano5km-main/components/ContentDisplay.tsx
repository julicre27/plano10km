import React from 'react';
import type { ProgramSection, WorkoutLog } from '../types';
import { CheckCircleIcon, CalendarIcon, LinkIcon } from './icons';

interface ContentDisplayProps {
  section: ProgramSection | undefined;
  workoutLogs: WorkoutLog[]; // Changed to array
  onOpenLogModal: (log?: WorkoutLog, index?: number) => void; // Changed signature
}

const ContentDisplay: React.FC<ContentDisplayProps> = ({ section, workoutLogs, onOpenLogModal }) => {
  if (!section) {
    return <div className="p-8 text-gray-500">Selecione um item no menu para começar.</div>;
  }
  
  const LoggedWorkoutDisplay: React.FC<{ log: WorkoutLog; index: number }> = ({ log, index }) => (
    <div className="mt-8 bg-green-50 border-l-4 border-brand-green p-4 sm:p-6 rounded-r-lg">
      <h3 className="font-bold text-lg text-green-800 flex items-center gap-2 mb-4">
        <CheckCircleIcon className="w-5 h-5 text-brand-green"/>
        Treino Registrado!
      </h3>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-green-700">
        <div>
          <p className="font-semibold text-green-800">Data do Treino</p>
          <p>{new Date(log.workoutDate + 'T00:00:00').toLocaleDateString('pt-BR')}</p> {/* Format date for display */}
        </div>
        <div>
          <p className="font-semibold text-green-800">Tempo</p>
          <p>{log.time}</p>
        </div>
        <div>
          <p className="font-semibold text-green-800">Distância</p>
          <p>{log.distance} km</p>
        </div>
        <div>
          <p className="font-semibold text-green-800">Esforço</p>
          <p>{log.effort}</p>
        </div>
      </div>
      {log.comments && (
         <div className="mt-4">
          <p className="font-semibold text-green-800">Comentários</p>
          <p className="text-green-700 italic bg-green-100 p-2 rounded">"{log.comments}"</p>
        </div>
      )}
      {log.stravaLink && (
        <div className="mt-4">
          <p className="font-semibold text-green-800">Strava</p>
          <a href={log.stravaLink} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-brand-blue hover:underline">
            <LinkIcon className="w-4 h-4" />
            Ver no Strava
          </a>
        </div>
      )}
      <button onClick={() => onOpenLogModal(log, index)} className="mt-4 text-sm font-semibold text-brand-blue hover:underline">
        Editar registro
      </button>
    </div>
  );


  return (
    <div className="flex-1 p-2 sm:p-4 md:p-8 overflow-y-auto">
      <div className="max-w-4xl mx-auto bg-white p-4 sm:p-8 rounded-lg shadow-md">
        {section.content}
        
        {workoutLogs && workoutLogs.length > 0 && (
            <div className="mt-8 space-y-4">
                {workoutLogs.map((log, index) => (
                    <LoggedWorkoutDisplay key={index} log={log} index={index} />
                ))}
            </div>
        )}

        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          {section.isLoggable && (
            <button
              onClick={() => onOpenLogModal()} // No arguments for new log
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 bg-white border-2 border-brand-blue text-brand-blue font-semibold rounded-lg shadow-sm hover:bg-indigo-50 transition-transform transform hover:scale-105"
            >
              <CalendarIcon />
              Registrar Treino Realizado
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ContentDisplay;