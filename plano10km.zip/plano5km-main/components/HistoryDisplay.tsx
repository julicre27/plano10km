import React from 'react';
import type { WorkoutLog, ProgramSection } from '../types';
import { HistoryIcon, LinkIcon } from './icons';

interface HistoryDisplayProps {
  workoutLogs: Record<string, WorkoutLog[]>; // Changed to array
  programSections: ProgramSection[];
}

const HistoryDisplay: React.FC<HistoryDisplayProps> = ({ workoutLogs, programSections }) => {
  const allLoggedWorkouts = programSections
    .filter(section => section.type === 'week' && workoutLogs[section.id] && workoutLogs[section.id].length > 0)
    .flatMap(section => 
        workoutLogs[section.id].map(log => ({
            sectionTitle: section.title,
            log: log,
            workoutDate: log.workoutDate // For sorting
        }))
    )
    .sort((a, b) => new Date(b.workoutDate).getTime() - new Date(a.workoutDate).getTime()); // Sort by workout date descending

  return (
    <div className="flex-1 p-2 sm:p-4 md:p-8 overflow-y-auto">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md mb-6">
            <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
                Histórico de Treinos
            </h1>
            <p className="text-brand-gray mt-1">Aqui estão todos os seus treinos registrados.</p>
        </div>

        {allLoggedWorkouts.length === 0 ? (
          <div className="text-center py-10 px-6 bg-white rounded-lg shadow-md">
            <h2 className="text-xl font-semibold text-gray-700">Nenhum treino registrado ainda</h2>
            <p className="text-gray-500 mt-2">Complete uma semana e registre seu treino para vê-lo aqui!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {allLoggedWorkouts.map(({ sectionTitle, log }, index) => (
              <div key={`${sectionTitle}-${index}`} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50">
                  <h3 className="text-lg font-bold text-gray-800">{sectionTitle}</h3>
                </div>
                <div className="p-4">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-700">
                        <div>
                            <p className="font-semibold text-gray-800">Data do Treino</p>
                            <p>{new Date(log.workoutDate + 'T00:00:00').toLocaleDateString('pt-BR')}</p> {/* Format date for display */}
                        </div>
                        <div>
                            <p className="font-semibold text-gray-800">Tempo</p>
                            <p>{log.time}</p>
                        </div>
                        <div>
                            <p className="font-semibold text-gray-800">Distância</p>
                            <p>{log.distance} km</p>
                        </div>
                        <div>
                            <p className="font-semibold text-gray-800">Esforço</p>
                            <p>{log.effort}</p>
                        </div>
                    </div>
                    {log.comments && (
                        <div className="mt-4">
                        <p className="font-semibold text-gray-800">Comentários</p>
                        <p className="text-gray-700 italic bg-gray-100 p-3 rounded mt-1">"{log.comments}"</p>
                        </div>
                    )}
                    {log.stravaLink && (
                      <div className="mt-4">
                        <p className="font-semibold text-gray-800">Strava</p>
                        <a href={log.stravaLink} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-brand-blue hover:underline">
                          <LinkIcon className="w-4 h-4" />
                          Ver no Strava
                        </a>
                      </div>
                    )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default HistoryDisplay;