import React, { useState, useEffect } from 'react';
import type { WorkoutLog } from '../types';
import { EffortLevel } from '../types';

interface LogWorkoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (log: WorkoutLog, logIndexToUpdate?: number) => void; // Changed signature
  weekTitle: string;
  existingLog: WorkoutLog | null;
  logIndexToUpdate: number | null; // New prop
}

const LogWorkoutModal: React.FC<LogWorkoutModalProps> = ({ isOpen, onClose, onSave, weekTitle, existingLog, logIndexToUpdate }) => {
  const [time, setTime] = useState('');
  const [distance, setDistance] = useState('');
  const [effort, setEffort] = useState<EffortLevel>(EffortLevel.Moderado);
  const [comments, setComments] = useState('');
  const [stravaLink, setStravaLink] = useState('');
  const [workoutDate, setWorkoutDate] = useState('');

  useEffect(() => {
    if (existingLog) {
      setTime(existingLog.time);
      setDistance(existingLog.distance);
      setEffort(existingLog.effort);
      setComments(existingLog.comments);
      setStravaLink(existingLog.stravaLink || '');
      setWorkoutDate(existingLog.workoutDate);
    } else {
      setTime('');
      setDistance('');
      setEffort(EffortLevel.Moderado);
      setComments('');
      setStravaLink('');
      // Set default workout date to today in YYYY-MM-DD format for input type="date"
      setWorkoutDate(new Date().toISOString().split('T')[0]); 
    }
  }, [existingLog, isOpen]);

  if (!isOpen) {
    return null;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      time,
      distance,
      effort,
      comments,
      logDate: new Date().toLocaleDateString('pt-BR'), // Date when the log was created/updated
      workoutDate, // Date when the workout was actually performed
      stravaLink: stravaLink || undefined, // Only include if not empty
    }, logIndexToUpdate !== null ? logIndexToUpdate : undefined); // Pass index if editing
    onClose();
  };
  
  const effortLevels = Object.values(EffortLevel);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-md animate-fade-in-up">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-800">Registrar Treino</h2>
          <p className="text-brand-gray">{weekTitle}</p>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-6 space-y-4">
            <div>
                <label htmlFor="workoutDate" className="block text-sm font-medium text-gray-700 mb-1">Data do Treino</label>
                <input
                    type="date"
                    id="workoutDate"
                    value={workoutDate}
                    onChange={(e) => setWorkoutDate(e.target.value)}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-blue focus:border-brand-blue"
                />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="time" className="block text-sm font-medium text-gray-700 mb-1">Tempo (mm:ss)</label>
                <input
                  type="text"
                  id="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  placeholder="ex: 45:30"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-blue focus:border-brand-blue"
                />
              </div>
              <div>
                <label htmlFor="distance" className="block text-sm font-medium text-gray-700 mb-1">Distância (km)</label>
                <input
                  type="text"
                  id="distance"
                  value={distance}
                  onChange={(e) => setDistance(e.target.value)}
                  placeholder="ex: 5.2"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-blue focus:border-brand-blue"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Sensação de Esforço</label>
              <select 
                value={effort} 
                onChange={(e) => setEffort(e.target.value as EffortLevel)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-blue focus:border-brand-blue bg-white"
              >
                {effortLevels.map(level => <option key={level} value={level}>{level}</option>)}
              </select>
            </div>
            <div>
              <label htmlFor="stravaLink" className="block text-sm font-medium text-gray-700 mb-1">Link do Strava (opcional)</label>
              <input
                type="url"
                id="stravaLink"
                value={stravaLink}
                onChange={(e) => setStravaLink(e.target.value)}
                placeholder="https://www.strava.com/activities/..."
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-blue focus:border-brand-blue"
              />
            </div>
            <div>
              <label htmlFor="comments" className="block text-sm font-medium text-gray-700 mb-1">Comentários</label>
              <textarea
                id="comments"
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                rows={3}
                placeholder="Como você se sentiu? Alguma observação?"
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-blue focus:border-brand-blue"
              ></textarea>
            </div>
          </div>
          <div className="p-4 bg-gray-50 border-t border-gray-200 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-brand-blue border border-transparent rounded-md text-sm font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              Salvar Treino
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LogWorkoutModal;