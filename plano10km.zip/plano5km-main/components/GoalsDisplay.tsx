import React, { useState, useMemo } from 'react';
import type { Goal, WorkoutLog } from '../types';
import { GoalType } from '../types';
import { TrophyIcon, TrashIcon } from './icons';

interface GoalsDisplayProps {
  goals: Goal[];
  workoutLogs: Record<string, WorkoutLog>;
  onAddGoal: (goal: Omit<Goal, 'id'>) => void;
  onDeleteGoal: (id: string) => void;
}

const GoalProgress: React.FC<{ goal: Goal; workoutLogs: Record<string, WorkoutLog>; onDelete: (id: string) => void }> = ({ goal, workoutLogs, onDelete }) => {
    
    const timeToSeconds = (time: string): number => {
        const [minutes, seconds] = time.split(':').map(Number);
        return (minutes || 0) * 60 + (seconds || 0);
    };

    // Parse date from YYYY-MM-DD format
    const parseDate = (dateStr: string): Date => {
        return new Date(dateStr + 'T00:00:00'); // Add T00:00:00 to ensure UTC interpretation for consistency
    };
    
    const { progressElement } = useMemo(() => {
        const logs: WorkoutLog[] = Object.values(workoutLogs);

        if (goal.type === GoalType.Frequency && goal.targetValue) {
            const oneWeekAgo = new Date();
            oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
            oneWeekAgo.setHours(0, 0, 0, 0); // Normalize to start of day

            const workoutsThisWeek = logs.filter(log => parseDate(log.workoutDate) >= oneWeekAgo).length;
            const progress = Math.min((workoutsThisWeek / goal.targetValue) * 100, 100);

            return {
                progressElement: (
                    <div>
                        <div className="flex justify-between items-center mb-1">
                            <span className="text-sm font-medium text-gray-700">Progresso</span>
                            <span className="text-sm font-medium text-brand-blue">{workoutsThisWeek} de {goal.targetValue} treinos</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                            <div className="bg-brand-blue h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
                        </div>
                    </div>
                )
            };
        }

        if (goal.type === GoalType.DistanceInTime && goal.targetDistance && goal.targetTime) {
            const relevantLogs = logs.filter(log => parseFloat(log.distance) >= goal.targetDistance);
            const bestLog = relevantLogs.reduce((best: WorkoutLog | null, current) => {
                if (!best) return current;
                return timeToSeconds(current.time) < timeToSeconds(best.time) ? current : best;
            }, null as WorkoutLog | null);

            return {
                progressElement: (
                     <div className="text-sm">
                        <span className="font-semibold text-gray-800">Seu melhor tempo para {goal.targetDistance}km: </span>
                        {bestLog ? <span className="font-bold text-brand-blue">{bestLog.time}</span> : <span className="text-gray-500">Nenhum treino relevante</span>}
                        <span className="text-gray-500 ml-2">(Meta: {goal.targetTime})</span>
                    </div>
                )
            }
        }

        return { progressElement: null };

    }, [goal, workoutLogs]);

    return (
        <div className="bg-white p-4 rounded-lg border border-gray-200 flex justify-between items-center">
            <div className="flex-1 pr-4">
                <p className="font-semibold text-gray-800">{goal.description}</p>
                <div className="mt-2">{progressElement}</div>
            </div>
            <button onClick={() => onDelete(goal.id)} className="text-gray-400 hover:text-red-600 p-2 rounded-full hover:bg-red-50">
                <TrashIcon />
            </button>
        </div>
    );
};

const GoalsDisplay: React.FC<GoalsDisplayProps> = ({ goals, workoutLogs, onAddGoal, onDeleteGoal }) => {
    const [description, setDescription] = useState('');
    const [type, setType] = useState<GoalType>(GoalType.Frequency);
    const [targetValue, setTargetValue] = useState(3);
    const [targetDistance, setTargetDistance] = useState(5);
    const [targetTime, setTargetTime] = useState('30:00');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if(!description) return;
        
        const newGoal: Omit<Goal, 'id'> = { description, type };
        if (type === GoalType.Frequency) {
            newGoal.targetValue = targetValue;
        } else {
            newGoal.targetDistance = targetDistance;
            newGoal.targetTime = targetTime;
        }
        onAddGoal(newGoal);
        setDescription('');
    };

  return (
    <div className="flex-1 p-2 sm:p-4 md:p-8 overflow-y-auto">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md mb-6">
          <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
            Minhas Metas
          </h1>
          <p className="text-brand-gray mt-1">Adicione metas e acompanhe seu progresso.</p>
        </div>
        
        <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md mb-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Adicionar Nova Meta</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">Descrição da Meta</label>
                    <input type="text" id="description" value={description} onChange={e => setDescription(e.target.value)} placeholder="Ex: Correr 3x por semana" required className="w-full px-3 py-2 border border-gray-300 rounded-md"/>
                </div>
                <div>
                    <label htmlFor="type" className="block text-sm font-medium text-gray-700 mb-1">Tipo de Meta</label>
                    <select id="type" value={type} onChange={e => setType(e.target.value as GoalType)} className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white">
                        <option value={GoalType.Frequency}>Frequência Semanal</option>
                        <option value={GoalType.DistanceInTime}>Distância em Tempo</option>
                    </select>
                </div>
                {type === GoalType.Frequency && (
                    <div>
                        <label htmlFor="targetValue" className="block text-sm font-medium text-gray-700 mb-1">Treinos por semana</label>
                        <input type="number" id="targetValue" value={targetValue} onChange={e => setTargetValue(Number(e.target.value))} min="1" className="w-full px-3 py-2 border border-gray-300 rounded-md"/>
                    </div>
                )}
                 {type === GoalType.DistanceInTime && (
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="targetDistance" className="block text-sm font-medium text-gray-700 mb-1">Distância (km)</label>
                            <input type="number" id="targetDistance" value={targetDistance} onChange={e => setTargetDistance(Number(e.target.value))} min="1" step="0.1" className="w-full px-3 py-2 border border-gray-300 rounded-md"/>
                        </div>
                        <div>
                            <label htmlFor="targetTime" className="block text-sm font-medium text-gray-700 mb-1">Tempo (mm:ss)</label>
                            <input type="text" id="targetTime" value={targetTime} onChange={e => setTargetTime(e.target.value)} placeholder="30:00" className="w-full px-3 py-2 border border-gray-300 rounded-md"/>
                        </div>
                    </div>
                 )}
                 <div className="text-right">
                    <button type="submit" className="px-5 py-2 bg-brand-blue text-white font-semibold rounded-md hover:bg-indigo-700">Adicionar Meta</button>
                 </div>
            </form>
        </div>

        <div>
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Metas Atuais</h2>
            {goals.length === 0 ? (
                 <div className="text-center py-10 px-6 bg-white rounded-lg shadow-md">
                    <h2 className="text-xl font-semibold text-gray-700">Nenhuma meta definida</h2>
                    <p className="text-gray-500 mt-2">Use o formulário acima para adicionar sua primeira meta!</p>
                </div>
            ) : (
                <div className="space-y-4">
                    {goals.map(goal => <GoalProgress key={goal.id} goal={goal} workoutLogs={workoutLogs} onDelete={onDeleteGoal} />)}
                </div>
            )}
        </div>

      </div>
    </div>
  );
};

export default GoalsDisplay;