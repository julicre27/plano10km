import React from 'react';
import type { WorkoutLog } from '../types';
import { ArrowTrendingUpIcon } from './icons';

interface ProgressChartProps {
  workoutLogs: Record<string, WorkoutLog>;
}

const ProgressChart: React.FC<ProgressChartProps> = ({ workoutLogs }) => {
  const logs = Object.values(workoutLogs);

  if (logs.length === 0) {
    return (
      <div className="flex-1 p-2 sm:p-4 md:p-8">
        <div className="max-w-4xl mx-auto text-center py-10 px-6 bg-white rounded-lg shadow-md">
          <h2 className="text-xl font-semibold text-gray-700">Ainda não há dados de progresso</h2>
          <p className="text-gray-500 mt-2">Registre seus treinos para começar a ver seu progresso aqui!</p>
        </div>
      </div>
    );
  }

  const totalDistance = logs.reduce((acc, log) => acc + parseFloat(log.distance || '0'), 0);
  const totalTimeSeconds = logs.reduce((acc, log) => {
    const parts = log.time.split(':').map(Number);
    return acc + (parts[0] || 0) * 60 + (parts[1] || 0);
  }, 0);
  const totalWorkouts = logs.length;

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    return `${h}h ${m}m`;
  };

  const avgDistance = (totalDistance / totalWorkouts).toFixed(2);
  const avgPace = totalDistance > 0 ? (totalTimeSeconds / 60) / totalDistance : 0; // minutes per km
  const avgPaceMinutes = Math.floor(avgPace);
  const avgPaceSeconds = Math.round((avgPace - avgPaceMinutes) * 60);

  return (
    <div className="flex-1 p-2 sm:p-4 md:p-8 overflow-y-auto">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md mb-6">
          <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
            <ArrowTrendingUpIcon className="text-brand-blue" />
            Seu Progresso
            </h1>
          <p className="text-brand-gray mt-1">Uma visão geral da sua jornada.</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg shadow-md text-center">
            <p className="text-sm font-medium text-gray-500">Treinos Totais</p>
            <p className="text-3xl font-bold text-brand-blue mt-2">{totalWorkouts}</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-md text-center">
            <p className="text-sm font-medium text-gray-500">Distância Total</p>
            <p className="text-3xl font-bold text-brand-blue mt-2">{totalDistance.toFixed(2)} <span className="text-lg">km</span></p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-md text-center">
            <p className="text-sm font-medium text-gray-500">Tempo Total</p>
            <p className="text-3xl font-bold text-brand-blue mt-2">{formatTime(totalTimeSeconds)}</p>
          </div>
        </div>
         <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md mt-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Métricas Médias por Treino</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                 <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-sm font-medium text-gray-500">Distância Média</p>
                    <p className="text-2xl font-bold text-gray-800 mt-1">{avgDistance} km</p>
                 </div>
                 <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-sm font-medium text-gray-500">Pace Médio</p>
                    <p className="text-2xl font-bold text-gray-800 mt-1">{avgPaceMinutes}'{avgPaceSeconds.toString().padStart(2, '0')}" <span className="text-base font-normal">/km</span></p>
                 </div>
            </div>
         </div>
      </div>
    </div>
  );
};

export default ProgressChart;
